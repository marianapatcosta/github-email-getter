# GitHub E-mail Getter

GitHub E-mail Getter is a simple chrome extension to extract the e-mail associated with the commits of a GitHub user. You enter GitHub username or URL and, if the email is public, the extension will extract it. 

![image](https://user-images.githubusercontent.com/43031902/215606660-b4586590-48dd-478f-ba0a-dedd1a7037ce.png)

Download it from [Chrome Web Store](https://chrome.google.com/webstore/detail/chrome-tabs-saver/kkpeppcnpfnpjemokcejjaliemaddcoc?hl=pt-PT&authuser=0).

## How to use

- Download project folder
- Open a Chrome window
- Go to `customise and control Google Chrome -> More Tools -> Extensions`
- Activate `developer mode`at top right corner toggle
- Click `Load unpacked` and select the folder where this project in stored in yourn computer
